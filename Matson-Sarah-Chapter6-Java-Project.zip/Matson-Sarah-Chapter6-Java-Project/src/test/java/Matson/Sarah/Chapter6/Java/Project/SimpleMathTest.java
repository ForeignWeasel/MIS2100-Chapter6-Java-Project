package Matson.Sarah.Chapter6.Java.Project;

import static org.junit.Assert.*;

import org.junit.Test;

public class SimpleMathTest {

	@Test
	public void testThatZeroNumeratorReturnsZero() {
		SimpleMath S = new SimpleMath();
		assertEquals(0.0, S.divide(0, 7), .000001);
	}
	
	@Test
	public void testThatSmallerNumeratorReturnsZero() {
		SimpleMath S = new SimpleMath();
		assertEquals(0.25, S.divide(1, 4), .001);
	}
	
	@Test(expected = ArithmeticException.class)
	public void testThatZeroDenominatorThrowsException() {
		SimpleMath S = new SimpleMath();
		S.divide(7, 0);
	}
}

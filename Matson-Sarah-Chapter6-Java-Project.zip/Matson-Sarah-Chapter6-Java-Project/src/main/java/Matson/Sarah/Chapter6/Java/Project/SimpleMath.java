package Matson.Sarah.Chapter6.Java.Project;

public class SimpleMath {

	public double divide(double num, double denom) {
		if (denom == 0) {
			throw new ArithmeticException("Can not divide by 0");
		}
		else {
			return num/denom;
		}
	}
	
	public double multiply(double m1, double m2) {
		return m1*m2;
	}
}

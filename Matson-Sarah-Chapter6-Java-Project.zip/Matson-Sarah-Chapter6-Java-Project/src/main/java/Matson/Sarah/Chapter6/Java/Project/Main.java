package Matson.Sarah.Chapter6.Java.Project;

import java.awt.EventQueue;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JFrame;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JButton;

public class Main {

	private JFrame frame;
	private JTextField textField;
	private JTextField textField_1;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Main window = new Main();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Main() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		SimpleMath SMath = new SimpleMath();
		double[] result = {0.0};
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		textField = new JTextField();
		textField.setBounds(38, 30, 96, 19);
		frame.getContentPane().add(textField);
		textField.setColumns(10);
		
		textField_1 = new JTextField();
		textField_1.setBounds(223, 30, 96, 19);
		frame.getContentPane().add(textField_1);
		textField_1.setColumns(10);
		
		JLabel lblNewLabel = new JLabel("Numerator");
		lblNewLabel.setBounds(58, 10, 76, 13);
		frame.getContentPane().add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Denominator");
		lblNewLabel_1.setBounds(237, 10, 75, 13);
		frame.getContentPane().add(lblNewLabel_1);
		
		JButton btnNewButton = new JButton("Calculate");
		btnNewButton.setBounds(142, 81, 96, 21);
		frame.getContentPane().add(btnNewButton);
		
		btnNewButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				double num = Double.parseDouble(lblNewLabel.getText());
				double den = Double.parseDouble(lblNewLabel_1.getText());
				if (den==0) {
					JLabel lblNewLabel_2 = new JLabel("Can't divide by 0");
					lblNewLabel_2.setBounds(152, 112, 96, 19);
					frame.getContentPane().add(lblNewLabel_2);

				}
				else {
				result[0] = SMath.divide(num, den);
				JLabel lblNewLabel_2 = new JLabel(Double.toString(result[0]));
				lblNewLabel_2.setBounds(152, 112, 96, 19);
				frame.getContentPane().add(lblNewLabel_2);

				}
			
			}
		});
		
	}
}
